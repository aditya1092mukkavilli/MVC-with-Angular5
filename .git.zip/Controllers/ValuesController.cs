﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication1.Models;


namespace WebApplication4.Controllers
{
    public class ValuesController : ApiController
    {
        public string Get(int id)
        {
            return "value";
        }

        [HttpGet]
        public List<Student> GetemployeeList()
        {
            //ResponseModel _objResponseModel = new ResponseModel();
            List<Student> students = new List<Student>();
            students.Add(new Student
            {
                ID = 101,
                Name = "Seam",
                Email = "seam@gmail.com",
                Address = "Dhaka,Bangladesh"
            });
            students.Add(new Student
            {
                ID = 102,
                Name = "Mitila",
                Email = "mitila@gmail.com",
                Address = "Dhaka,Bangladesh"
            });
            students.Add(new Student
            {
                ID = 104,
                Name = "Popy",
                Email = "popy@yahoo.com",
                Address = "Dhaka,Bangladesh"
            });
            //_objResponseModel.Date = students;
            //_objResponseModel.Status = true;
            //_objResponseModel.Message = "Data Received successfully";
            return students;
        }
        //POST api/values
        public void Post([FromBody]string value)
        {
        }
        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }
        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
